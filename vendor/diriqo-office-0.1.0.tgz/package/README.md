# Diriqo Office

Sdílený kancelářský modul pro JSPD Hub a Diriqo: Tiptap OSS, FortuneSheet, vlastní bezpečnostní a formátové adaptéry. Základní funkce nevyužívají placené SDK, externí licenční server ani cloud výrobce editoru.

## Spuštění lokální ukázky

Použijte Node 24. Nejprve ověřte existující licenční evidenci, teprve potom instalujte:

```sh
node scripts/licenses.mjs --check
npm ci --ignore-scripts --no-audit --no-fund
npm test
npm run build
npm run demo:build
npm run demo
```

Otevřete `http://127.0.0.1:4320`. Testovací účty Alfa vlastník/editor/čtenář a Beta vlastník mají oddělený obsah. Data se ukládají do `demo/data/office.json`. Server je určen pouze pro místní ukázku. Při restartu se přihlaste znovu; dokumenty zůstanou na disku.

## Co je připraveno

- Textový editor, skutečný spreadsheet s výpočty, pracovní plocha, složky a vyhledávání.
- Automatické ukládání, souběžné revize, historie a obnova, kopie, autorizované vazby na zákazníka a zakázku.
- Šest parametrických šablon; DOCX/XLSX v popsané podmnožině, CSV/TXT/HTML a [stažitelný PDF s českým vloženým fontem](docs/PDF_EXPORT.md).
- Neměnné originály, audit, tenantová autorizace, schvalované návrhy Diriqenta a idempotence.
- Integrační změny v `integrations/hub` a `integrations/diriqo`, jeden sdílený distribuční balíček a SQL migrace.
- Licenční evidence nových závislostí, SBOM a CI blokující neověřený graf.

## Stav a hranice ověření

Veřejný staging je ověřený v obou hostitelích. Lokálně prošlo **159 společných testů, 81 hostitelských testů a 247 SQL kontrol** (Hub 133, Diriqo 114). Oba izolované cloudové buildy jsou READY. Přesné deploymenty, shodu balíčku a výsledky uvádí `reports/public-staging-final-local.json`; podrobnosti jsou v [testování](docs/TESTING.md).

SQL testy používaly databáze v paměti a minimální autentizační fixtures. Neověřují skutečný Supabase JWT gateway, produkční granty ani souběh více spojení. PGlite se s Office nedistribuuje a není součástí auditu 129 nových Office závislostí; licenční rozsah existujícího testovacího prostředí je vysvětlen v TESTING.md.

Do původních checkoutů ani produkčních dat, migrací a nastavení Office se nezapisovalo. Oba hostitelé prošli samostatnými skutečnými staging testy: každý 410 RPC kontrol včetně izolace dvou firem, rolí, souběhu a obnovy. JSPD má 50 a Diriqo 48 veřejných HTTP kontrol přes skutečné SSR přihlášení; oba ověřily importní worker s 20 000 buňkami. Chrome ověřil obnovu a bezpečné přepínání firem mezi panely; skutečný PDF export byl nezávisle parsovaný a vykreslený. Nativní tiskový náhled a fyzická tiskárna zůstávají neověřené. Finální výsledek a omezení jsou ve [stagingovém protokolu](docs/STAGING_ACCEPTANCE.md) a `reports/validation.json`. Modul zůstává výchozně vypnutý; zapnuté jsou jen syntetické stagingové firmy.

Úplná kompatibilita Word/Excel, spolupráce v reálném čase a opakované stránkové záhlaví nejsou deklarovány.

Pro opakování slouží [staging spouštěč a postup](docs/STAGING_RUNBOOK.md). Aktuální [veřejný staging](docs/PUBLIC_STAGING.md) platí nejdéle do **12. 10. 2026 19:00 Praha**, úklid je naplánovaný na 18:55. Předchozí odstraněné větve a jejich cleanup reporty jsou historické. Aktivní cíle určují `reports/staging-targets.json` a `reports/public-staging-targets.json`; síťové testy odmítají produkční projekty. Soukromé testovací přístupy jsou v místním `.staging/PUBLIC_ACCESS.md`, mimo distribuční archiv.

Podrobnosti: [architektura](docs/ARCHITECTURE.md), [výběr technologií](docs/TECHNOLOGY_DECISION.md), [reálná omezení](docs/LIMITATIONS.md), [zapnutí a distribuce](docs/ENABLEMENT.md), [testování](docs/TESTING.md), [licenční audit](LICENSE_AUDIT.md), [původ vizuálních prvků](ASSET_LICENSES.md).

Při změně závislostí nejdříve upravte pouze deklarace/lockfile bez instalace, spusťte `npm run license:preflight`, zkontrolujte celý diff evidence a teprve po úspěšném auditu instalujte. CI důkazy samo nepřepisuje. Vlastní zdroje Office jsou proprietární; `UNLICENSED` neznamená licenci třetích stran.
