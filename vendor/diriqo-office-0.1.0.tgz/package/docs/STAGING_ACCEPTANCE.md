# Diriqo Office — veřejný staging a akceptace

Ověřeno 11. 10. 2026. Oba skutečné hostitelské weby běží v samostatných Vercel staging projektech. Každý používá svou prázdnou Supabase větev naplněnou pouze syntetickými daty. Produkční projekty, domény, databáze ani nastavení Office se v tomto běhu neměnily. Výsledek je připravený pro řízený pilot v uvedených mezích.

| Prostředí | Veřejná adresa | Přesný deployment |
| --- | --- | --- |
| JSPD Hub | https://office-staging-nyf1c56p4-jspdholding-7510s-projects.vercel.app/office | dpl_AhzzQw6qDKuDyMm98kzr7FwxyNdv |
| Diriqo | https://office-staging-diriqo-lr75qtgw0-jspdholding-7510s-projects.vercel.app/office | dpl_2pPWyUrNHLWzefSow12Tkshw9xCn |

Přístup vyžaduje aplikační přihlášení. Soukromé údaje testovacího manažera obou firem jsou místně v `.staging/PUBLIC_ACCESS.md`, mimo Git, deployment i distribuční archiv. Produkční účty se nekopírovaly.

## Ověřené výsledky

| Kontrola aktuálního běhu | JSPD Hub | Diriqo |
| --- | ---: | ---: |
| Skutečný Auth/RPC, dvě firmy, role, historie, schválení AI a idempotence | 410 PASS | 410 PASS |
| Souběžné požadavky: jedno vítězné uložení, zastaralá revize odmítnuta | 3 kola PASS | 3 kola PASS |
| Výchozí vypnutí a oprávnění zapnout Office | 14 PASS | 14 PASS |
| Veřejný host: SSR, import/export worker, negativní přístupy a PDF | 50 PASS | 48 PASS |
| Anonymní veřejné routy a omezení stagingu | 7 PASS | 7 PASS |
| Názvy firem přes omezené Hub RPC: členství, cizí firma, anon a limity | 11 PASS | — |
| Diriqo capability bez grantu / s testovacím grantem | — | 6 / 2 PASS |

HTTP testy zahrnují DOCX, XLSX, CSV, neměnné originály, opakování importu, čtenářská práva, cizí firmu, kontrolu originu, podvržený ZIP a XLSX s 20 000 vyplněnými buňkami. Jde o reprezentativní test, nikoli úplný výkonový benchmark.

Lokálně prošlo **159 společných testů, 81 hostitelských testů a 247 SQL kontrol** (Hub 133, Diriqo 114). Oba cloudové optimalizované buildy jsou READY. Přesná shoda distribuovaného balíčku s oběma instalacemi, zdrojové hashe a výsledky jsou v `reports/public-staging-final-local.json`. Licenční kontrola prošla pro **129 přesných nových závislostí a jeden font pod OFL**. Nebyla přidána placená knihovna ani licenční server.

## Skutečný Chrome a PDF

- Oba hostitelé: původní obsah v revizi 2, změna v revizi 3, potvrzení obnovy vytvoří revizi 4 se shodným původním obsahem. Hub dialog byl proveden v předchozím staging buildu; uložená revize byla znovu otevřena a ověřena v konečném deploymentu. Přesné identity uvádí browser report.
- Oba hostitelé: druhý panel přepne aktivní firmu A → B. Původní dokument zůstane připnutý k A, pokus uložit je odmítnut, rozepsaný text zůstane. Načtený seznam B dokument A neobsahuje. Po návratu k A a výslovném opakování se uloží revize 5. Hub revize 5 byla znovu otevřena; oba uložené obsahy nezávisle potvrdil následný export.
- Diriqo: sešit formula-demo.xlsx po zadání A1 = 30, automatickém uložení a novém otevření zachoval revizi 3, SUM = 50, AVERAGE = 25 a odkaz na druhý list = 7500.
- Hub: běžný manažer vidí názvy oprávněných firem a vytvořil nabídku s autorizovaným názvem firmy. Nové RPC vrací pouze názvy/ID jeho zapnutých firem; původní role a tabulkové RLS se nemění.
- PDF skutečně vrácené veřejným autorizovaným endpointem je pro oba hostitele uložené, nezávisle parsované a vykreslené. Kontrola váže SHA256 na odpověď, ověřuje původní český text, částku, A4 a vložený OFL font. Důkazy jsou v `output/pdf/public-*-restored*`.

**Nativní tiskový náhled a fyzická tiskárna nejsou ověřené.** Podporované ovládání Chrome nezpřístupnilo nativní tiskové UI. PDF z aplikačního exportu je ověřené samostatně. Událost browser download se nepodařilo zachytit; skutečné HTTP bajty nejsou vydávány za důkaz cesty staženého souboru v Chrome. Tiskové CSS a volání jsou implementované, viz [PDF_EXPORT.md](PDF_EXPORT.md).

## Rozsah a před nasazením

Hub staging obnovuje pouze technické závislosti Office z dříve schváleného schématu; Diriqo používá zdrojově ověřený základ Office. Nejde o úplné kopie ERP. Starší testy vypnutí během běžícího zápisu s doloženými databázovými zámky, přímého RLS a vazeb na záznamy patří předchozím odstraněným větvím; jejich původní čas a projectRef zůstávají v historických reportech. Nejsou označené za nově provedené proti veřejným větvím.

Před produkcí zbývá řízené schválení nasazení, kontrola konkrétního cílového schématu a záloh, provozní kapacity a reprezentativních zákaznických DOCX/XLSX. První adaptér má **64 MiB na firmu včetně historie a originálů**, web upload **3 MiB** a popsané limity JSON transportu. Pro větší provoz je potřeba privátní Storage a oddělená historie. Úplná regionální lokalizace spreadsheet enginu, dokonalé stránkování, real-time spolupráce a koš UI nejsou hotové. Podrobnosti: [LIMITATIONS.md](LIMITATIONS.md), [ENABLEMENT.md](ENABLEMENT.md).

## Platnost, úklid a předání

Schválené okno končí **12. 10. 2026 v 19:00 Praha**. Na 18:55 je naplánovaný úklid pouze těchto dvou větví a samostatných staging projektů. Odhad compute obou větví za 24 hodin je **0,64512 USD**, schválený strop je 1 USD; nejde o fakturu ani cenu organizačního předplatného. Server po expiraci přístup zablokuje, ale účtování ukončí až odstranění prostředků. Úklid je zatím naplánovaný, nikoli vykonaný; vyžaduje následný vlastní report.

Aktuální souhrn: `reports/validation.json`. Veřejné cíle: `reports/public-staging-targets.json`. UI důkazy: `reports/public-staging-browser.json`. Starší staging-cleanup.json patří předchozímu běhu.

Předání: `release/diriqo-office-source-and-integrations.zip`, `release/diriqo-office-0.1.0.tgz`, dvě integrační záplaty a přesné základní revize v `release/DELIVERY.json`. Zdrojový archiv obsahuje aktuální dokumentaci i důkazy; neměnný testovaný runtime balíček nebyl po nasazení přebalen kvůli textové dokumentaci. Neproběhl push ani produkční deployment.
